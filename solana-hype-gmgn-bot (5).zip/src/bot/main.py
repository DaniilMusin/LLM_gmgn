import asyncio
from .engine import Orchestrator
if __name__ == "__main__":
    o = Orchestrator(); asyncio.run(o.run())
